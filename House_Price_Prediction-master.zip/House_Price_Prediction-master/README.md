# House_Price_Prediction
This model predicts house prices in **Boston city** to help users to get an *estimation* of housing prices

**WELCOME PAGE**
![1st](https://user-images.githubusercontent.com/37214962/71351382-859b6880-2599-11ea-96c8-af512fd262a7.png)


**Price prediction**
![2nd](https://user-images.githubusercontent.com/37214962/71351393-91872a80-2599-11ea-8f7f-b2c7a2032354.png)


**Graph that denotes the accuracy of predicted value**
![3rd](https://user-images.githubusercontent.com/37214962/71351469-c2675f80-2599-11ea-94a1-47a8b78e98b6.png)


**Graphical data dependency**
![5th](https://user-images.githubusercontent.com/37214962/71351485-ca270400-2599-11ea-858e-5b6663f0aae2.png)


**User can view data as per price range they want and also can adjust the columns they want to compare house prices with**
![4th](https://user-images.githubusercontent.com/37214962/71351491-ceebb800-2599-11ea-9854-c614232d901c.png)

